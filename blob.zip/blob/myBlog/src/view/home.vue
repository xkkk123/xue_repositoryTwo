<template>
    <main class="main">
        <div class="home">
            <navs/>
            <div class="info">
                <span class="rotate"></span>
                <span class="rotate"></span>
                <span class="rotate"></span>
                <span class="rotate"></span>
                <span class="info-content">
                    <div>
                        <h1>XUE KAI</h1>
                        <h3>Here's an argvchs...</h3>
                    </div>
                </span>
            </div>
        </div>
        <cards/>
        <footers/>
    </main>

</template>

<script lang="ts" setup>
import navs from "../components/home/nav.vue";
import cards from "../components/home/card.vue";
import footers from "../components/footer.vue";


// onMounted(()=>{
    
// })

</script>

<style lang="less" scoped>
.main{
    position: relative;
    background-color: #f6f8fa;
}
.home{
    width: 100vw;
    height: 100vh;
    background-image: url(https://uploadstatic.mihoyo.com/contentweb/20210804/2021080419123130780.png);
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    .info{
        position: relative;
        display: flex;
        justify-content: center;
        width: 100%;
        height: 100%;
        span{
            position: absolute;
            top: 15%;
            background-color: #f6f8fa;
            border-radius: 38% 62% 63% 37%/41% 44% 56% 59%;
        }
        & span:nth-child(1){
            transform: rotate(30deg);
            opacity: .3;
            animation: rotate1 10s linear infinite;
        }
        & span:nth-child(2){
            transform: rotate(60deg);
            opacity: .45;
            animation: rotate2 15s linear infinite;
        }
        & span:nth-child(3){
            transform: rotate(90deg);
            opacity: .3;
            animation: rotate3 10s linear infinite;
        }
        & span:nth-child(4){
            transform: rotate(120deg);
            opacity: .45;
            animation: rotate4 15s linear infinite;
        }
        & span:nth-child(5){
            display: flex;
            justify-content: center;
            align-items: center;
            color: #1e3e3f;
            border-radius: 50%;
            opacity: .6;
            font-size: 16px;
            div{
                text-align: center;
                z-index: 10;
            }
        }
    }
}
@keyframes rotate1 {
    from{
        transform: rotate(30deg);
    }
    to{
        transform: rotate(390deg);
    }
}
@keyframes rotate2 {
    from{
        transform: rotate(60deg);
    }
    to{
        transform: rotate(420deg);
    }
}
@keyframes rotate3 {
    from{
        transform: rotate(90deg);
    }
    to{
        transform: rotate(450deg);
    }
}
@keyframes rotate4 {
    from{
        transform: rotate(120deg);
    }
    to{
        transform: rotate(480deg);
    }
}

@media (min-width: 900px) {
    .rotate{
        width: 500px;
        height: 500px;
    }
    .info-content{
        width: 500px;
        height: 500px;
    }
}

@media (max-width: 900px) {
    .info-content{
        width: 350px;
        height: 350px;
        opacity: .8;
        top: 30%;
    }
}
</style>