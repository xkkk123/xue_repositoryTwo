<template>
    <div class='login-home'>
        <div class="login-box">
            <div class="login-container" :style="{ transform:`translateX(${move}%)`}">
                <section class="register box" v-if="!show">
                    <h2>RIGHISTER</h2>
                    <input v-model="user.username" placeholder="用户名" type="text" required />
                    <input v-model="user.password" placeholder="密码" type="password" required/>
                    <input v-model="repassword" placeholder="确认密码" type="password" required/>
                    <input v-model="user.email" placeholder="邮箱" type="email" required/>
                    <input v-model="user.phone" placeholder="手机号" type="tel" required/><br/>
                    <button @click="register()">注册</button>
                </section>
                <section class="login box" v-if="show">
                    <h2>LOGIN</h2>
                    <input v-model="username" placeholder="用户名" type="text" required/>
                    <input v-model="password" placeholder="密码" type="password" required/><br/>
                    <button @click="login()">登录</button>
                </section>
            </div>
            <div class="card">
                <section class="register-card">
                    <h2>欢迎来到<span>~~~~</span></h2>
                    <p>blog</p>
                    <img src="/1675145558695.png" alt="">
                    <p>已有账号</p>
                    <button @click="showFun()">去注册</button>
                </section>
                <section class="login-card">
                    <h2>欢迎来到<span>~~~~</span></h2>
                    <p>blog</p>
                    <img src="/1675317842964.png" alt="">
                    <p>没有账号?</p>
                    <button @click="showFun()">去登录</button>
                </section>
            </div>
        </div>
        
    </div>
</template>
<script lang='ts'>
import { ref,reactive  } from "vue";
import { ElMessage} from 'element-plus'
import { getLogin,insertUser } from "../api/userApi";


interface User {
    username:string,
    password:string,
    email:string,
    phone:string
}

let show=ref<boolean>(true)
let move=ref<number>(80)
let input=ref<string>('')
let username=ref<string>('')
let password=ref<string>('')
let repassword=ref<string>('')



const user:User=reactive({
    username:'',
    password:'',
    email:'',
    phone:''
})
const rule={
    usernameReg:/^[\u4E00-\u9FFF0-9A-z]{6,12}$/,
    passwordReg:/^[0-9A-z]{6,12}$/,
    emailReg:/^\w+@\w+\.com$/,
    phoneReg:/^(13|14|15|18[0-9])[0-9]{8}$/
}
</script>
<script setup lang='ts'>
import { useRouter } from 'vue-router'
const router=useRouter();
function showFun(){
    if(show.value===true){
        move.value=0
    }else{
        move.value=80
    }
    show.value=!show.value;
}

async function login() {
    if (!username.value||!password.value) {
        if (!username.value) {
            ElMessage({
                message:"请填写用户名",
                type:'error'
            })
            return;
        }
        ElMessage({
            message:"请填写密码",
            type:'error'
        })
        return;
    }
    if(rule.usernameReg.test(username.value)&&rule.passwordReg.test(password.value)){
        try {
            const {data:res}=await getLogin({username:username.value,password:password.value})
            if (res.code===200) {
                localStorage.setItem("token",res.data)
                ElMessage({
                    message:res.msg,
                    type:'success'
                })
                setTimeout(()=>{
                    router.push({path:'home'})
                },1500)
                

                username.value='';
                password.value='';
            }else{
                ElMessage({
                    message:res.msg,
                    type:'error'
                })
            }
        } catch (error) {
                ElMessage({
                    message:"服务器繁忙，请稍等！",
                    type:'error'
                })
                throw new Error("error"); 
        }
    }else{
        ElMessage({
            message:'格式错误',
            type:'error'
        })
    }
    
}

async function register() {
    if(!rule.usernameReg.test(user.username)&&!rule.passwordReg.test(user.password)&&!rule.phoneReg.test(user.phone)&&!rule.emailReg.test(user.email)){
        ElMessage({
                message:"请输入正确的格式",
                type:'error'
            })
        return;
    }
    if(user.password===repassword.value){
            try {
                const {data:res}=await insertUser(user)
                console.log(res)
                if (res.code===200) {
                    ElMessage({
                        message:res.msg,
                        type:'success'
                    })

                }else{
                    ElMessage({
                        message:res.msg,
                        type:'error'
                    })
                }
            } catch (error) {
                ElMessage({
                    message:"服务器繁忙，请稍等！",
                    type:'error'
                })
                throw new Error("error"); 
            }
        }else{
            ElMessage({
                message:"两次密码不一致",
                type:'error'
            })
        }
        user.username='';
        user.password='';
        user.phone='';
        user.email='';
        repassword.value=''
}


</script>

<style scoped lang='less'>
.login-home{
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100vw;
    height: 100vh;
    border: 0;
    background: linear-gradient(200deg,#f3e7e9,#e3eeff);

    .login-box{
        position: relative;
        width: 650px;
        height: 415px;
        background-color: white;
        box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.1),-5px -5px 5px rgba(0, 0, 0, 0.1);
    }
    .login-container{
        position: absolute;
        left: 5%;
        top: -10%;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 320px;
        height: 500px;
        background-color: #d3b7d8;
        border-radius: 5px;
        box-shadow: 5px 10px 10px rgba(0, 0, 0, 0.1);
        transform: translateX(0%);
        transition:all 1s;
        z-index: 2;
        .box{
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            color: white;
            letter-spacing: 5px;
            input{
                background-color: transparent;
                border: none;
                border-bottom: 1px solid rgba(255, 255, 255, 0.4);
                text-indent: 2px;
                letter-spacing: 3px;
                padding: 5px;
                &::placeholder{
                    color: #fff;
                }
                &:focus{
                    color: #a262ad;
                    outline: none;
                    border-bottom: 1px solid #a262ad80;
                }
                &:focus::placeholder{
                    opacity: 0;
                }
            }
            button{
                width: 60%;
                padding: 11px;
                margin-top: 30px;
                background-color: #f6f6f6;
                color: #a262ad;
                border: none;
                letter-spacing: 2px;
                border-radius: 8px;
                outline: none;
                cursor: pointer;
                &:hover{
                    background-color: #a262ad;
                    color: white;
                    transition: background-color 0.5s ease;
                }
            }
        }
    }
    .card{
        display: flex;
        justify-content:space-around;
        align-items: center;
        text-align: center;
        h2{
            color: #8e9aaf;
            font-size: 25px;
            font-weight: bold;
            letter-spacing: 3px;
            margin-bottom: 4px;
            span{
                color: #d3b7d8;

            }
        }
        p{
            font-size: 12px;
            color: #8e9aaf;
            letter-spacing: 2px;
        }
        img{
            width: 150px;
            height: 200px;
            opacity: 0.9;
        }
        button{
            color:#a262ad ;
            background-color: #fff;
            border: 1px solid #d3b7d8;
            padding: 6px 10px;
            outline: none;
            letter-spacing: 1px;
            border-radius: 5px;
            &:hover{
                background-color: #d3b7d8;
                color: white;
            }
        }
    }
}



/* @media screen and (max-width: 750px){
    .login-home .login-box{
        position: initial;
        background-color: transparent;
        box-shadow: none;
    }
    .login-home .login-box .login-container{

        top: 0;
        left: 18vw;
        transform: translate(30%,50%) !important;
    }
    .login-home .card{
        display: none;
    }
} */
</style>