<template>
    <div class="archives-home">
        <navs/>
        <div class="search">
            <input type="search" placeholder="搜索" v-model.trim="search">
        </div>
        <el-timeline>
            <KeepAlive>
                <el-timeline-item hollow="true" placement="top" type="primary" v-for="item in data" :key="item.id" :timestamp="item.date">
                    <el-card>
                        <router-link :to="'/detail/'+item.id">
                            <h2>{{item.title}}</h2>
                        </router-link>
                        <div class="tags-box">
                            <router-link :to="'/categories/'+item.categories"><CollectionTag class="icon"/>{{item.categories}}</router-link>&nbsp;&nbsp;&nbsp;
                            <span class="tags">
                               <PriceTag class="icon"/> <router-link v-for="child in item.tags" :to="'/tags/'+child">{{child}}</router-link>
                            </span>
                        </div>
                    </el-card>
                </el-timeline-item>
            </KeepAlive>
        </el-timeline>
        <footers/>
    </div>

  </template>

<script setup lang="ts">
import navs from "../components/home/nav.vue"
import footers from "../components/footer.vue";
import {ref,watch } from "vue";
import { CollectionTag,PriceTag} from "@element-plus/icons-vue";
import { getArticleAll,getLikeArticle } from "../api/article";

interface article{
  id:number,
  title:string,
  tags:Array<string>,
  categories:string,
  date:string
}

const data=ref<Array<article>>([]);
const search=ref('')

getData() 
async function getData(){
    const {data:res}=await getArticleAll();
    data.value=res.data.result
    console.log(data.value);
    
}
watch(search,async (newVal,oldVal)=>{
    try {  
        console.log(oldVal);
        
        const {data:res}=await getLikeArticle(newVal);
        data.value=res.data.result;
    } catch (error) {
       throw new Error(<string>error)
    }
})
</script>

<style lang="less" scoped>
.archives-home{
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    padding-top: 100px;
    background-color: #f6f8fa;
}
.search{
    width: 900px;
    padding-left: 40px;
    margin: 25px 0;
    text-align: center; 
    
    input{
        width:100%;
        padding: 10px 20px;
        height: 50px;
        border-radius: 25px;
        border: 1px solid #d0d7de;
        
        &:focus{
            border: 3px solid skyblue;
            box-shadow: 2px 2px 10px 0 skyblue;
            outline: none;
        }
    }
}
.tags-box{
    a{
        font-weight: 700;
        color: #1e3e3f;
        &:hover{
            opacity: 0.8;
        }
    }
}
.tags{
    a{
        color: #66afef;
        margin-right: 10px;   
    }

}
.el-timeline{
    color: #1e3e3f; 
    font-weight: 700;
    a{
        h2{
           color: #1e3e3f; 
           
           font-size: 24px;
           &:hover{
            opacity: 0.8;
           }
        }
        
        
    }
}
.icon{
        width: 15px;
        vertical-align:middle;
        margin-right: 8px;
        padding-bottom: 3px;
    }
@media (min-width: 900px ) {
    .el-timeline{
        width:900px ;
    }
    
}
</style>