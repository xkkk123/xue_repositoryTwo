<template>
    <navs/>
    <div class="about-home">
        <div class="about-container">
            <div>
                <h2>About</h2>
                <p>2022/10/12</p>
            </div>
            <div>
                <h1>Hi there<span>👋</span></h1>
                <hr>
                <div class="introduce">
                    <p>一名前端新手</p>
                </div>
                <h2><span>💡</span>语言</h2>
                <ul class="language">
                    <li>
                        HTML/CSS
                    </li>
                    <li>
                        JAVASCRIPT
                    </li>
                    <li>
                        VUE
                    </li>
                    <li>
                        NODE.JS
                    </li>
                </ul>
                <h2><span>✨</span> 账号</h2>
                <table class="table-home">
                    <colgroup>
                        <col style="width: 9%;">
                        <col style="width: 90%;">
                    </colgroup>
                    <thead>
                        <tr class="header">
                            <th style="text-align: center;">网站</th>
                            <th style="text-align: left;">账号</th>
                        </tr>
                    </thead>
                    <tbody class="table-body">
                        <tr>
                            <td>QQ</td>
                            <td><a href="http://wpa.qq.com/msgrd?v=3&uin=2310341704&site=qq&menu=yes" target="_blank">2310341704</a></td>
                        </tr>
                        <tr>
                            <td>email</td>
                            <td><a href="" target="_blank">2310341704@qq.com</a></td>
                        </tr>
                        <tr>
                            <td>GitHub</td>
                            <td> <a href="" target="_blank">XUEKAI</a></td>
                        </tr>

                    </tbody>
                </table>
                <p class="avatar">
                    <img src="https://static-argvchs.netlify.app/images/avatar.jpg">
                </p>
            </div>
        </div>
        <footers/>
    </div>
    
</template>

<script setup lang="ts">
import navs from "../components/home/nav.vue"
import footers from "../components/footer.vue";
</script>

<style lang="less" scoped>
.about-home{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    width: 100%;
    padding-top: 100px;
    background-color: #f6f8fa;
}
.introduce{
    border-left: 3px solid #1e3e3f;
    background: #d9e8ff6b;
    border-radius: 3px;
    margin: 15px 0;
    overflow: auto;
    padding: 0 15px;
    p{
        line-height: 1.7;
        margin: 15px 0;
        font-weight: 700;
        font-size: 15px;
        // word-spacing: 30px;
        letter-spacing: 3px;
    }
}
.language{
    li{
        margin: 10px 0;
        font-size: 15px;
        font-weight: 700;
        color: #1e3e3f;
    }
}
.table-home{
    th,td{
        padding: 10px 20px;
    }
}
.header{
    th{
        background: #a3ddfb;
        font-weight: 700;
        font-size: 15px;
        
    }
}
.table-body{
    font-size: 15px;
    font-weight: 700;
    tr{
        & td:nth-child(2){
            text-align: left;
        }
        a{
            color:#66afef;
        }
    }
    td{
        background: #d9e8ff4d;
        text-align: center;
        color: #1e3e3f;
    }
}
.avatar{
    text-align: center;
    img{
        width: 30%;
        border-radius: 50%;
    }
}

hr{
    border-style: dashed none none;
    // border-width: 1px;
}
h1{
    font-size: 35px;
    margin: 30px 0 10px 0;
}

h2{
   font-size: 30px;
   margin: 10px 0; 
}
@media (min-width: 900px ) {
    .about-container{
        width:900px;
    }
    
}
@media (max-width: 900px ) {
    .about-home{
        padding:100px 15px 15px 15px;
    }

    
}
</style>