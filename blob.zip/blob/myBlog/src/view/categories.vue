<template>
    <navs/>
    <div class="categories-home">
        <div class="categories-container">
            <div class="categories-content">
                <router-link :to="'/categories/'+item.categoriesname+'/'" v-for="item in data" >
                    <CollectionTag class="icon"/><span>{{item.categoriesname}}</span>
                </router-link>
            </div>

            <el-timeline>
                <el-timeline-item hollow placement="top" type="primary" v-for="item in articleData" :key="item.id" :timestamp="item.date">
                    <el-card>
                        <router-link :to="'/detail/'+item.id">
                            <h2>{{item.title}}</h2>
                        </router-link>
                        <div class="tags-box">
                            <router-link :to="'/categories/'+item.categories"><CollectionTag class="icon"/>{{item.categories}}</router-link>&nbsp;&nbsp;&nbsp;
                            <span class="tags">
                               <PriceTag class="icon"/> <router-link v-for="child in item.tags" :to="'/tags/'+child">{{child}}</router-link>
                            </span>
                        </div>
                    </el-card>
                </el-timeline-item>
            </el-timeline>
        </div>
    </div>
    <footers/>
</template>

<script setup lang="ts">
import navs from "../components/home/nav.vue"
import footers from "../components/footer.vue";
import {ref } from "vue";
import {CollectionTag,PriceTag} from "@element-plus/icons-vue";
import { useRoute} from 'vue-router'
import { getCategoriesArticle } from "../api/article";
import { getCategories } from "../api/categories";

interface categories{
    id:number,
    categoriesname:string
}
interface article{
  id:number,
  title:string,
  tags:Array<string>,
  categories:string,
  date:string
}

const route=useRoute();
// const router=useRouter();
const data=ref<Array<categories>>([]);
const articleData=ref<Array<article>>([]) 

getData()
async function getData(){
    const {data:res}=await getCategories();
    data.value=res.data.result;  
}

getArticleData()
async function getArticleData() {
    const {data:res}= await getCategoriesArticle(<string>route.params.categorie);
    console.log(res);
    articleData.value=res.data.result
    // 
} 
// router.go(0)

</script>

<style lang="less" scoped>
.categories-home{
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    width: 100%;
    padding-top: 100px;
    min-width: 375px;
}

.categories-content{
    display: flex;
    justify-content: center;
    margin-bottom: 100px;
    a{
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
        background-color: #66afef;
        // width: 60px;
        border-radius: 10px;
        padding: 10px 15px;
        margin: 10px;
        border:1px solid #66afef;
        font-weight: 700;
        transition: all 0.5s;
        &:hover{
            color: #1e3e3f;
            background-color: white;
            
        }
    }
}
.tags-box{
    .icon{
       color: #1e3e3f; 
       padding-bottom: 3px;
    }
    a{
       color: #66afef;  
    }
   
}
.icon{
    width: 15px;
    vertical-align:middle;
    // color: #1e3e3f;
    margin-right: 8px;
    // padding-bottom: 3px;
}
.tags{
    a{
        margin-right: 10px;
    }
}
.el-timeline{
    color: #1e3e3f; 
    font-weight: 700;
    padding-left: 0;
    a{
        h2{
           color: #1e3e3f; 
           
           font-size: 24px;
           &:hover{
            opacity: 0.8;
           }
        }
        
        
    }
}
@media (min-width: 900px ) {
    .el-timeline{
        width:900px;
    }
    
}
@media (max-width: 900px ) {
    .categories-container{
        width:100%;
        padding: 0 20px;
    }
    .el-timeline{
        width:90%;
    }
    
}
</style>