<template>
        
        <main>
            <navs/>
            <editors/>
            <footers/>
        </main>
        
</template>

<script lang="ts" setup>
import navs from "../components/home/nav.vue";
import footers from "../components/footer.vue"
import editors from "../components/editor.vue";


</script>

<style lang="less" scoped></style>