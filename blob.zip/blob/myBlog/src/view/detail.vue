<template>
        <navs/>
        <div class="detal-home">
                <div class="detal-container">
                        <div class="detal-content">
                                <div class="title">
                                        <h1>{{data[0].title}}</h1>
                                </div>
                                <div class="info">
                                        <span>
                                                <Aim class="icon"/> {{ data[0].date }}  
                                        </span>
                                        <span class="categories">
                                                <CollectionTag class="icon"/> 
                                                <router-link :to="'/categories/'+data[0].categories">{{ data[0].categories }}</router-link>
                                        </span>
                                        <span class="tags">
                                                <PriceTag class="icon"/>
                                                <router-link :to="'/tags/'+data[0].tags"> {{data[0].tags }}</router-link>
                                        </span>
                                </div>
                                <div class="content" v-html="data[0].htmltext"></div>
                        </div>
                </div>
              <footers/>  
        </div>
        
</template>

<script lang="ts" setup>
import navs from "../components/home/nav.vue";
import footers from "../components/footer.vue";
import {ref} from "vue";
import { useRoute } from 'vue-router'
import { getArticleById } from "../api/article";
import {CollectionTag,PriceTag,Aim} from "@element-plus/icons-vue";

interface Article {
    id:number,
    title:string,
    tags:string,
    htmltext:string,
    synopsis:string,
    categories:string,
    date:string
}


const route=useRoute();
const id=<string>route.params.id;
const data=ref<Array<Article>>([]);

getData()    
async function getData(){
        const {data:res}=await getArticleById(parseInt(id));
        data.value=res.data.result; 
          console.log(res);
          
}


</script>

<style lang="less" scoped>
.detal-home{
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        background-color: #f6f8fa;
        width: 100%;
        height: 100%;
        padding-top: 100px;
        h1{
                margin: 0;
                font-size: 30px;
        }
}
.info{
   display: flex; 
   margin: 15px 0;
        span{
                margin:5px;
                font-size: 14px;
                font-weight: 700;
                color: #5c6b72;
                a{
                        font-size: 14px;
                        font-weight: 600;
                        color: #5c6b72;
                        &:hover{
                                opacity: 0.8;
                        }
                }
        }
        .tags{
                a{
                        color: rgb(3, 169, 244); 
                        margin-right: 5px;
                }
        }
        .categories{
                a{
                  color: rgb(255, 125, 115);      
                }
        }
}

.icon{
        width: 15px;
        vertical-align:middle;
        margin-right: 5px;
        padding-bottom: 3px;
        
}
@media (min-width: 900px ) {
        .detal-container{
                width: 800px;
        }
}
</style>