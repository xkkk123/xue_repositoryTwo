import request from"../utils/axiosConfig";

export const getLogin=function(data:object) {
    return request.post('/login',data)
}

export const insertUser=function(data:object){
    return request.post('/register',data);
}

