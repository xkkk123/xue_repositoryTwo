import request from"../utils/axiosConfig";

export const getCategories=function() {
    return request.get('/getCategories')
}



