import request from"../utils/axiosConfig";

export const setArticle=function(data:object){
    return request.post("/setArticle",data)
}

export const getArticleById=function(id:number){
    return request.get("/getArticleById",{
        params:{
            id
        }
    })
}
export const getArticleAll=function(){
    return request.get("/getArticleAll")
}

export const getArticle=function(page:number,limit:number){
    return request.get("/getArticle",{
        params:{
            page,
            limit
        }
    })
}

export const getCategoriesArticle=function(categorie:string){
    return request.get("/getCategoriesArticle",{
        params:{
            categorie
        }
    })
}

export const getTagsArticle=function(tag:string){
    return request.get("/getTagsArticle",{
        params:{
            tag
        }
    })
}

export const getLikeArticle=function(title:string){
    return request.get("/getLikeArticle",{
        params:{
            title
        }
    })
}