import request from"../utils/axiosConfig";

export const getTags=function() {
    return request.get('/getTags')
}



