import { createRouter,createWebHistory } from 'vue-router'
import { ElMessage } from "element-plus";
const routes=[
{
    path:"/",
    redirect:'/login'
},
{
    path:'/login',
    name:'login',
    component:()=>import('../view/login.vue')
},
{
    path:"/home",
    name:'home',
    component:()=>import('../view/home.vue')
},
{
    path:"/posts",
    name:"posts",
    component:()=>import("../view/posts.vue")
},
{
    path:"/detail/:id",
    name:"detail",
    component:()=>import("../view/detail.vue")
},
{
    path:"/categories/:categorie",
    nama:"categories",
    component:()=>import("../view/categories.vue"),
    porp:true
},
{
    path:"/archives",
    name:"archives",
    component:()=>import("../view/archives.vue")
},
{
    path:"/tags/:tag",
    name:"tags",
    component:()=>import("../view/tags.vue"),
    porp:true
},
{
    path:"/about",
    name:"about",
    component:()=>import("../view/about.vue")
}
]

const route=createRouter({
    routes,
    history: createWebHistory()
})


route.beforeEach((to,from,next)=>{
    console.log(from);
    
    const token=localStorage.getItem("token")
    if (to.name!=='login'&&!token) {
        ElMessage({
            message:"请登录"
        })
        next({name:"login"})
    }else{
        next()
    }
})
export default route;