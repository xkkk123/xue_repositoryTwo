<template>
    <footer class="footer">
        <div class="footer-content">
            <div>© 2022 - 2023 XUEKAI QAQ <el-icon><Flag /></el-icon> @XUEKAI</div>
            <div></div>
        </div>
    </footer>
</template>

<script lang="ts" setup>
import { Flag} from "@element-plus/icons-vue";
</script>

<style lang="less" scoped>
.footer{
    display: flex;
    justify-content: center;
    // margin-top: 150px;
    padding-top: 150px;
    background-color: #f6f8fa;
    .footer-content{
        box-sizing: border-box;
        border-top: 1px solid #aaa;
        padding:30px 0;
        font-size: 15px;
        font-weight: 600;
        color: #5c6b72;
        text-align: center;
    }
}
.el-icon{
    vertical-align: middle;
    color: #66afef;
}
@media (min-width: 900px) {
    .footer-content{
        width: 900px;
    }
}
@media (max-width: 900px) {
    .footer-content{
        width: 100%;
    }
}
</style>