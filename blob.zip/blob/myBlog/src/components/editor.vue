<template>
  <div class="editor-home">
    <div class="editor-container">
      <div class="inputBox">
        <span>
            <el-input v-model="infoObj.title" placeholder="标题" required/>
        </span>
        <span>
            <el-input v-model="infoObj.synopsis" placeholder="简介" required/>
        </span>
        <span>
            <el-input v-model="infoObj.tags" placeholder="标签" required/>
        </span>
        <span>
            <el-input v-model="infoObj.categories" placeholder="分类" required />
        </span>
      </div>
      <div style="border: 1px solid #ccc" class="editor">
        <Toolbar
          style="border-bottom: 1px solid #ccc"
          :editor="editorRef"
          :defaultConfig="toolbarConfig"
          :mode="mode"
        />
        <Editor
          style="height: 500px; overflow-y: hidden;"
          v-model="infoObj.htmltext"
          :defaultConfig="editorConfig"
          :mode="mode"
          @onCreated="handleCreated"
        />
      </div>
      <el-button type="primary" @click="submit()">发布</el-button>
    </div>
  </div>


</template>

<script lang="ts" setup>
import '@wangeditor/editor/dist/css/style.css'
import { Editor, Toolbar } from '../../node_modules/@wangeditor/editor-for-vue'
import { ElMessage} from 'element-plus'
import {reactive, onBeforeUnmount,shallowRef,ref} from 'vue'
import { setArticle } from "../api/article";

interface InfoObj{
  title:string,
  synopsis:string,
  tags:string,
  categories:string,
  htmltext:string,
  date:string
}
interface myObj{
  [key:string]:any
}

const infoObj:InfoObj=reactive({
  title:'',
  synopsis:'',
  tags:'',
  categories:'',
  htmltext:'',
  date:''
})
const editorRef = shallowRef()
const mode=ref("false")
const toolbarConfig = {}
const editorConfig:myObj = { 
  placeholder: '请输入内容...' ,
  MENU_CONF:{} 
}

editorConfig.MENU_CONF['uploadImage']={
  server:'http://localhost:8081/upload',
  allowedFileTypes: ['image/*'],
  base64LimitSize: 5 * 1024,
  meta:{token:localStorage.getItem('token')},
  // metaWithUel:true,
  headers:{Authorization:`Bearer ${localStorage.getItem('token')}`},
    onBeforeUpload(files: File){
      return files;
    },

    // 单个文件上传成功之后
    onSuccess(file: File, res: any) {  // TS 语法
        console.log(`${file.name} 上传成功`, res)
    },

    // 单个文件上传失败
    onFailed(file: File, res: any) {   // TS 语法
        console.log(`${file.name} 上传失败`, res)
    },

    // 上传错误，或者触发 timeout 超时
    onError(file: File, err: any, res: any) {  // TS 语法
        console.log(`${file.name} 上传出错`, err, res)
    },
}

async function submit(){
  const timer=new Date()
  const date=timer.toLocaleDateString()
  infoObj.date=date;
  const {data:res}=await setArticle(infoObj)
  console.log(res)
  if (res===200) {
    ElMessage({
      type:'success',
      message:'文章上传成功'
    })
  }
  infoObj.title=''
  infoObj.synopsis=''
  infoObj.tags=''
  infoObj.htmltext=''
}

// 组件销毁时，也及时销毁编辑器
onBeforeUnmount(() => {
    const editor = editorRef.value
    if (editor == null) return
    editor.destroy()
})

const handleCreated = (editor: any) => {
    editorRef.value = editor // 记录 editor 实例，重要！
}
</script>

<style lang="less" scoped>
  .editor-home{
    display: flex;
    justify-content: center;
    width: 100%;
  }
  .editor-container{
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 20px;
    margin-top: 100px;
    width: 800px;
  }
  .inputBox{
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    width: 100%;
    span{
      margin:0 5px;
      text-align: center;
    }
  }
  // .el-input{
  //   width: 150px;
  // }
  .editor{
    width: 100%;
    /* height: 100px; */
  }

</style>