<template>
    <section class="card-home" :style="{ transform:`translateY(-${move}px)`}">
        <div class="card-container">
            <div class="card-content">
                <div class="card">
                    <router-link to="/home">
                        <h2>ParticleX 主题使用说明</h2>
                    </router-link>
                    <div class="category-and-date">
                        <CollectionTag class="icon"/>
                        <span><router-link to="/home"><span>教程</span></router-link></span>
                        <span><span>2022/5/10</span></span>
                    </div>
                    <p class="description">ParticleX 主题，诞生原因是因为原来的 Particle 主题不维护了，但是我觉得还是很好的。</p>
                    <div class="tags">
                        <PriceTag class="icon"/>
                        <span><router-link to="/home">主题</router-link></span>
                        <span><router-link to="/home">ParticleX</router-link></span>
                    </div>
                    <router-link to="/home" class="read-btn">阅读全文</router-link>
                </div>
                <div class="card" v-for="item in data" :key="item.id">
                    <router-link :to="'/detail/'+item.id">
                        <h2>{{ item.title }}</h2>
                    </router-link>
                    <div class="category-and-date">
                        <CollectionTag class="icon"/>
                        <span><router-link :to="'/categories/'+item.categories"><span>{{item.categories}}</span></router-link></span>
                        <span><span>{{ item.date }}</span></span>
                    </div>
                    <p class="description">{{item.synopsis}}</p>
                    <div class="tags">
                        <PriceTag class="icon"/>
                        <span v-for="child in item.tags"><router-link :to="'/tags/'+child">{{child}}</router-link></span>
                    </div>
                    <router-link :to="'/detail/'+item.id" class="read-btn">阅读全文</router-link>
                </div>
                <div class="page">
                    <el-pagination
                        v-model:current-page="currentPage"
                        small="true"
                        background="false"
                        layout="pager"
                        :total="total"
                        @current-change="handleCurrentChange"
                    />
                </div>
            </div>
            <div class="avatar-home">
                <div class="avatar-conent">
                    <div class="avatar">
                        <img src="https://static-argvchs.netlify.app/images/avatar.jpg">
                        <div class="author-name">XUEKAI</div>
                        <div class="signature">Here an argvchs...</div>
                    </div>
                    <div class="icon-links">
                        <span><a href=""><i class="iconfont icon-github"></i></a></span>
                        <span><a href="http://wpa.qq.com/msgrd?v=3&uin=2310341704&site=qq&menu=yes" target="_blank"><i class="iconfont icon-QQ"></i></a></span>
                        <span><a href=""><i class="iconfont icon-ion-social-twitter"></i></a></span>
                        <span><a href="http://mailto:xuekaiqaq@163.com" target="_blank"><i class="iconfont icon-xinfengtianchong"></i></a></span>
                    </div>
                    <div class="friend-links"></div>
                </div>
            </div>
        </div>

    </section>     



</template>

<script lang="ts" setup>
import {CollectionTag,PriceTag} from "@element-plus/icons-vue";
import { ref,onMounted ,reactive} from "vue";
import { getArticle } from "../../api/article";
// import { useRouter } from 'vue-router'

interface Article {
    id:number,
    title:string,
    tags:Array<string>,
    categories:string,
    htmltext:string,
    synopsis:string,
    date:string
}

let move=ref<number>(0);
const currentPage = ref(1)
const total = ref(0)
let data=reactive<Array<Article>>([])
onMounted(()=>{
    document.addEventListener("scroll",()=>{
        if(scrollY/5<=80){
           move.value=scrollY/5 
        }
    })
   
})
getData(currentPage.value);
async function getData(page:number) {
    const {data:res}=await getArticle(page,10)
    data=res.data.result;
    total.value=res.data.total
    console.log(data);
    
}
// const router=useRouter()
// const reload=inject('reload')
const handleCurrentChange = (val: number) => {
  getData(val);
//   router.go(0)
//   reload()
}
</script>

<style lang="less" scoped>
.card-home{
    display: flex;
    align-items: center;
    box-sizing: border-box;
    flex-direction: column;
    width: 100%;
    padding: 20px;
    .card-container{
        display: flex;
        justify-content: center;
        
        .card-content{
            display: flex;
            flex-direction: column;
            align-items: center;
        }
    }
    .card{
        position: relative;
        box-sizing: border-box;
        height: 300px;
        color: #1e3e3f;
        background-color: #fff;
        border-radius: 20px;
        box-shadow: 5px 0px 20px #d9d9d980;
        transition: box-shadow .25s,transform .25s;
        font: 600 14px Lexend,"Noto Sans SC",sans-serif;
        margin-bottom: 30px;
        &:hover{
            transform: translate(-5px,-5px);
        }
        a{
            text-align: center;
            font-size: 15px;
            &:hover{
                opacity: 0.8;
            }
            h2{ 
                color: #66afef;
                font-weight: 700;
                margin: 10px 0;
            }
        }
        .category-and-date{
            display: flex;
            justify-content: center;
            color: #5c6b72;
            a{
                font-weight: 600;
                color: #5c6b72;
                
            }
            & span:nth-child(1){
                margin-left: 20px;
            }
        }
        .description{
            padding: 35px 0;
        }
        .tags{
            span{
                margin: 0px 5px;
                a{
                    font-weight: 700;
                    color: #66afef;

                }
            }
        }
        .read-btn{
            position: absolute;
            right: -5px;
            bottom: -5px;
            padding: 10px 20px;
            color: white;
            font-weight: 700;
            border-radius: 20px 0 20px 0;
            background-image: linear-gradient(120deg,#9abbf7 0,#ffbbf4 100%);
            box-shadow: 2px 2px 10px #ffbbf47a;
            transition: box-shadow 0.5s;
            &:hover{
                box-shadow: -2px -2px 10px #9abbf77a;
                right: -7px;
            }
        }
    }
    .avatar-home{
        position: sticky;
        top: 150px;
        width: 300px;
        height: 500px;
        padding: 20px;
        color: #1e3e3f;
        box-sizing: border-box;
        background-color: white;
        box-shadow: 0px 0px 20px #d9d9d980;
        border-radius: 15px;
        transform: top 0.3s;
        .avatar-conent{
            text-align: center;
            .avatar{
                    font-weight: 700;
                img{
                    border-radius: 50%;
                    width: 150px;
                    height: 150px;
                }
                .author-name{
                    font-size: 16px;
                    margin: 15px 0;
                }
                .signature{
                    font-size: 15px;
                }
            }
            .icon-links{
                display: flex;
                justify-content: space-around;
                border-top: #cdcdcd solid 1px;
                border-bottom: #cdcdcd solid 1px;
                padding: 10px;
                margin:10px 0;
                span{
                    width: 35px;
                    height: 35px;
                    border-radius: 8px;
                    i{
                        font-size: 25px;
                        color: #5c6b72;
                    }
                    &:hover{
                        background-color:#66afef;
                    }
                    &:hover i{
                        color: white;
                    }
                }
            }
        }
    }
}
.icon{
    width: 15px;
    vertical-align:middle;
    margin-right: 8px;
}

.page{
    margin-top: 80px;
}

@media (min-width:1200px) {
    .card-container{
       width: 1200px;
    }
    .card{
        width: 850px;
    }
}

@media (min-width:900px) {
    .card-content{
        margin-right: 50px;
        width: 850px;
    }
    .card{
        padding: 50px;
        min-width: 665px;
    }
}
@media (min-width:900px) and (max-width:1200px) {
    .avatar-home{
        display: none;
    }
    .card-container{
        width: 800px; 
    }
    .card-content{
        width: 100%;
        padding: 0 20px;
    }
}

@media screen and (max-width:900px) {
    .avatar-home{
        display: none;
    }
    .card-container{
        width: 100%; 
    }
    .card-content{
        width: 100%;
    }
    .card{
        width: 100%;
        padding: 20px 30px;
    }
}
</style>