<template>
    <div class="menu" :style="{top:`${top}px`,backgroundColor:`${bgc}`}">
        <nav class="nav-PC-home nav">
            <router-link to="/home">XUEKAI</router-link>
            <router-link to="/home"><House class="nav-icon"/>Home</router-link>
            <router-link to="/about"><Postcard class="nav-icon"/>About</router-link>
            <router-link to="/archives"><TakeawayBox class="nav-icon"/>Archives</router-link>
            <router-link to="/categories/null"><CollectionTag class="nav-icon"/>Categories</router-link>
            <router-link to="/tags/null"><PriceTag class="nav-icon"/>Tags</router-link>
            <router-link to="/posts"><Notebook class="nav-icon"/>posts</router-link>
        </nav>
        <nav class="nav-mobile-home nav" @click="clickMenu()">
            <div class="menu" >
                <Menu class="nav-icon" />
                <span >XUEKAI</span>
            </div>
            <transition name="fade-menus">
                <div class="menus" v-if="show">
                    <router-link to="/home"><House class="nav-icon"/><span>Home</span></router-link>
                    <router-link to="/about"><Postcard class="nav-icon"/><span>About</span></router-link>
                    <router-link to="/archives"><TakeawayBox class="nav-icon"/><span>Archives</span></router-link>
                    <router-link to="/categories/null"><CollectionTag class="nav-icon"/><span>Categorues</span></router-link>
                    <router-link to="/tags/null"><PriceTag class="nav-icon"/><span>Tags</span></router-link>
                    <router-link to="/posts"><Notebook class="nav-icon"/><span>posts</span></router-link>
                </div>
            </transition>
        </nav>
    </div>

</template>

<script lang="ts" setup>
import { House,TakeawayBox,CollectionTag,Postcard,PriceTag,Menu,Notebook} from "@element-plus/icons-vue";
import { ref,onMounted} from "vue";

let show=ref(false);
let top=ref(0)
let bgc=ref("#0003")


function clickMenu(){
    show.value=!show.value
}

let s=0;
onMounted(()=>{
    let h=window.innerHeight
    document.addEventListener("scroll",()=>{
        bgc.value=scrollY>h?"#92cafa":"#0003"
        if(s<scrollY){
            s=scrollY
            top.value=-50
        }else{
            s=scrollY
            top.value=0;
        }
    })
})
</script>

<style lang="less" scoped>

.menu{
    position:fixed;
    width: 100%;
    background-color: #0003;
    transition: top 0.5s ease-in-out;
    z-index: 9999;
}

.nav{
    position: relative;
    width: 100%;
    .nav-icon{
        width: 15px;
        vertical-align:middle;
        margin-right: 8px;
    }
}


.nav-PC-home{
    display: flex;
    justify-content:left;
    height: 50px;
    & a:nth-child(1){
        margin-left: 50px;
     }
     a{
        line-height: 50px;
        margin-left: 30px;
        font-size: 15px;
        font-weight: 700;
        color: white;
        text-decoration: none;
        &:hover{
            color: #e7f0fa;
        }
     }  
}
.nav-mobile-home{
    /* position: fixed; */
    display: none;
    color: white;
    font-size: 15px;
    font-weight: 700;
    line-height: 50px;
    .nav-icon{
       margin-bottom: 3px;
       margin-right: 15px;
    }
    .menu{
        position: relative;
        display: flex;
        justify-content: center;
        text-align: center;
        cursor: pointer;
        z-index: 1000;
    }
    .menus{
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        a{
            display: flex;
            justify-content: center;
            line-height: 50px;
            margin-left: 30px;
            font-size: 15px;
            font-weight: 700;
            width: 180px;
            color: white;
            text-decoration: none;
            /* text-align: center; */
            span{
                width: 100px;
                text-align: center;
            }
            &:hover{
                color: #e7f0fa;
            }
        }
    }
}

.fade-menus-enter-active,
.fade-menus-leave-active {
    transition: margin-top 0.3s;
    margin-top: 0;
}

.fade-menus-enter-from,
.fade-menus-leave-to {
    margin-top: -250px;
    opacity: 0;
}

@media screen and (max-width: 900px) {
    .nav-PC-home{
        display: none;
    }
    .nav-mobile-home{
        display: block;
    }

}

</style>