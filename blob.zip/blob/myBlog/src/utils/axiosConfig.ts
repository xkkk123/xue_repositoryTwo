import axios from 'axios'
import  router  from "../router/index";
import { ElMessage } from "element-plus";

const server=axios.create({
    baseURL:'http://localhost:8081',
    timeout:60000
})

server.interceptors.request.use((config)=>{
    const token = localStorage.getItem("token");
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
},(err)=>{

    return Promise.reject(err);
})

server.interceptors.response.use((response)=>{
    // console.log(response)
    return response
},(err)=>{
    const { code } = err;
    ElMessage.error("账号已过期，请重新登录");
    // router.push("login");
    if (code === "ERR_NETWORK") {
      router.push("login");
    }
    return Promise.reject(err);
})

export default server;