<script setup lang="ts">
import { useRoute } from "vue-router";
// import { nextTick,provide,ref } from "vue";
const route=useRoute()
// const isRouterAlive=ref(true)
// const reload=()=>{
//     isRouterAlive.value=false;
//     nextTick(()=>{
//         isRouterAlive.value=true;
//     })
// }

// provide("reload",reload)
</script>

<template>
<router-view :key="route.path"/>
</template>

<style scoped></style>

