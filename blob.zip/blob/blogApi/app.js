const express=require('express');
const fs=require('fs')

const {expressjwt}=require('express-jwt');
const userRouter=require('./controller/userController');
const articleRouter=require('./controller/articleController')
const categoriesRouter=require('./controller/categoriesController');
const tagsRouter=require('./controller/tagsController')
const app=express();
const multiparty=require('multiparty');

const secretKey='xuekai'
app.use(express.urlencoded({ extended: false }))
app.use(express.json());
app.use(expressjwt({ secret: secretKey,algorithms:['HS256']}).unless({path:[/^(\/login|\/uploads)/]}))

app.use((req,res,next)=>{
    res.setHeader('Access-Control-Allow-Origin',"*")
    res.setHeader('Access-Control-Allow-Headers',"X-Requested-With,Content-Type,Authorization")
    res.setHeader('Access-Control-Allow-Methods',"PUT,POST,GET,DELETE")
    next()
})

app.use(function (err, req, res, next) {
    if (err.name === "UnauthorizedError") {
      res.status(401).send("invalid token...");
    } else {
      next(err);
    }
});

app.use([userRouter,articleRouter,categoriesRouter,tagsRouter])

app.post('/upload',function(req,res){
    let form=new multiparty.Form({uploadDir:'./uploads'})
    form.parse(req,(err,msg,files)=>{
     const file=files['wangeditor-uploaded-image'][0]
     const newPath=__dirname+"/"+form.uploadDir.substring(1)+'/'+file.originalFilename;
     const path=req.protocol+"://"+req.headers.host+form.uploadDir.substring(1)+'/'+file.originalFilename;
      fs.rename(file.path,newPath,(err)=>{
        if (err) {
          console.log(err);
        }
        res.sendStatus=200;
        res.send({
          "errno":0,
          "data":{
            "url":path
          }
        })

      })
    })
})

app.use('/uploads',express.static('uploads'))


app.listen(8081,function(){
    console.log("启动成功")

})