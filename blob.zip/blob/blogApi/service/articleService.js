const articleMapper=require('../mapper/articleMapper')
const tagsMapper=require("../mapper/tagsMapper")
const categoriesMapper=require("../mapper/categoriesMapper")
exports.setArticle=async (article)=>{
    try {
        const data=await articleMapper.setArticle(article);
        const tagsArr=article.tags.split(',')
        insertTags(tagsArr);
        insertCategories(article.categories)
        return data
    } catch (error) {
        return error;
    }
}

exports.getArticleAll=async ()=>{
    try {
        const data=await articleMapper.getAtricleAll();
        data.result.forEach(item => {
            item.tags=item.tags.split(",")
        });
        return data;
    } catch (error) {
        return error;
    }
}

exports.getArticle=async (page,limit)=>{
    try {
        const data=await articleMapper.getAtricle(page*1,limit*1);
        data.result.forEach(item => {
            item.tags=item.tags.split(",")
        });
        const count=await articleMapper.getCount();
        data.total=count.result[0]['COUNT(id)']
        return data;
    } catch (error) {
        return error;
    }
}

exports.getArticleById=async (id)=>{
    try {
        const data=await articleMapper.getAtricleById(id);
        return data;
    } catch (error) {
        return error
    }
}

exports.getCategoriesArticle=async (categorie)=>{
    try {
        const data=await articleMapper.getAtricleByCategories(categorie)
        data.result.forEach(item => {
            item.tags=item.tags.split(",")
        });
        return data;
    } catch (error) {
        return error
    }
}

exports.getTagsArticle=async (tag)=>{
    try {
        const data=await articleMapper.getAtricleByTags(tag)
        data.result.forEach(item => {
            item.tags=item.tags.split(",")
        });
        return data;
    } catch (error) {
        return error
    }
}

exports.getLikeArticle=async (title)=>{
    try {
      const data= await articleMapper.getLikeAtricle(title)
      data.result.forEach(item => {
        item.tags=item.tags.split(",")
    });
    console.log(data);
    return data;
    } catch (error) {
        return error;
    }
}

function insertTags(tags) {
    try {
        tags.forEach(async (item)=>{
            const data= await tagsMapper.getTagsCount(item)
            if (data.result[0]['COUNT(tagname)']===0) {
                tagsMapper.insertTags(item)
            }
        }) 
    } catch (error) {
        return error;
    }
}

async function insertCategories(categories) {
    try {
            const data= await categoriesMapper.getCategoriesCount(item)
            if (data.result[0]['COUNT(categories)']===0) {
                categoriesMapper.insert(item)
            }
    } catch (error) {
        return error;
    }
}