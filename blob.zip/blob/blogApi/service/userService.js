const crypto=require('crypto')
const userMapper=require('../mapper/userMapper');
const jwt=require('jsonwebtoken');
const md5=crypto.createHash('md5')

const mySecret='xuekai'

exports.login=((user)=>{
    return new Promise((resolve,reject)=>{
        userMapper.queryByUserName(user).then((res)=>{
            if (res.result.length===1&&res.result[0].password===user.password) {
                const token=jwt.sign({username:res.result[0].username},mySecret,{expiresIn:'6h'})
                resolve(token)
            }else{
                reject(res.err)
            }
        })
    }) 
})

exports.insertUser=(user)=>{
    return new Promise((resolve,reject)=>{
        userMapper.queryByUserName(user).then(res=>{
            if(res.result.length===1){
                reject(null)
            }else{
                user.password=md5.update(user.password).digest('hex');
                userMapper.insertUser(user).then((res)=>{
                    resolve(res)
                })
            }
        })

    }) 
}