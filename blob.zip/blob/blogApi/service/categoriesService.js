const categoriesMapper=require('../mapper/categoriesMapper')

exports.getCategories=async ()=>{
    try {
        const data=await categoriesMapper.getCategories();
        return data;
    } catch (error) {
        return error
    }
}