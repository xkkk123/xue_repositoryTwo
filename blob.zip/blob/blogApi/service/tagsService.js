const tagsMapper=require('../mapper/tagsMapper')


exports.getTags=async ()=>{
    try {
        const data= await tagsMapper.getTags()
        return data
    } catch (error) {
        return error
    }
    
}
