const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);


const sql={
    queryAll:"SELECT *FROM user",
    query:"SELECT *FROM user WHERE username=?",
    insert:"INSERT INTO user(username,password,email,phone) VALUES(?,?,?,?)",
    update:"UPDATE FROM user SET username=?,password=? WHERE id=?",
    delete:"DELETE FROM user WHERE id=?"
}

exports.queryByUserName=((user)=>{
    return new Promise(function(resolve,reject){
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.query,[user.username],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.insertUser=((user)=>{
    return new Promise((resolve,reject)=>{
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.insert,[user.username,user.password,user.email,user.phone],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        }) 
    })
})