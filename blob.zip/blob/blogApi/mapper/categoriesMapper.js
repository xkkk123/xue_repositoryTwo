const mysql=require('mysql')
const config=require('../mysql/config');
const pool=mysql.createPool(config);


const sql={
    queryAll:"SELECT id,categoriesname FROM categories",
    getCategoriesCount:"SELECT COUNT(categoriesname) FROM categories WHERE categories=?",
    insert:"INSERT INTO categories(categoriesname) VALUES(?)"
}

exports.getCategories=()=>{
    return new Promise((resolve,reject)=>{
        pool.getConnection((err,connection)=>{
            if (err) reject(err)
            connection.query(sql.queryAll,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })    
            connection.end()
        })
    })
}

exports.getCategoriesCount=(categories)=>{
    return new Promise((resolve,reject)=>{
        pool.getConnection((err,connection)=>{
            if (err) reject(err)
            connection.query(sql.getCategoriesCount,categories,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })    
            connection.end()
        })
    })
}

exports.insert=(categories)=>{
    return new Promise((resolve,reject)=>{
        pool.getConnection((err,connection)=>{
            if (err) reject(err)
            connection.query(sql.getCategoriesCount,categories,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })    
            connection.end()
        })
    })
}