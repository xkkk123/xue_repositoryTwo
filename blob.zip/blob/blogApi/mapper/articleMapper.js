const mysql=require('mysql')
const config=require('../mysql/config');
const pool=mysql.createPool(config);


const sql={
    insert:"INSERT INTO article(title,tags,categories,htmltext,synopsis,date) VALUES(?,?,?,?,?,?)",
    queryCount:"SELECT COUNT(id) FROM article",
    queryAll:"SELECT id,title,tags,categories,date FROM article",
    queryById:"SELECT *FROM article where id=?",
    queryLimit:"SELECT * FROM article LIMIT ?,?",
    queryCategories:"SELECT id,title,tags,categories,date FROM article WHERE categories=?",
    queryTags:`SELECT id,title,tags,categories,date FROM article WHERE tags LIKE ?`,
    queryLike:"SELECT id,title,tags,categories,date FROM article WHERE title LIKE ?"
}

exports.setArticle=(article)=>{
    console.log(article);
    return new Promise((resolve,reject)=>{
        
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.insert,[article.title,article.tags,article.categories,article.htmltext,article.synopsis,article.date],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
        
    })
}

exports.getAtricleAll=()=>{
    return new Promise((resolve,reject)=>{
        pool.getConnection((err,connection)=>{
            if (err) reject(err)
            connection.query(sql.queryAll,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
    })
}

exports.getAtricleById=(id)=>{
    return new Promise((resolve,reject)=>{
        pool.getConnection((err,connection)=>{
            if(err) reject(err);
            connection.query(sql.queryById,id,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
    })
}

exports.getCount=()=>{
    return new Promise((resolve,reject)=>{
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryCount,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
        
    })
}

exports.getAtricle=(page,limit)=>{
    return new Promise((resolve,reject)=>{
        pool.getConnection((err,connection)=>{
            if(err){
               reject(err); 
            } 
            connection.query(sql.queryLimit,[(page-1)*limit,limit],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
    })
}

exports.getAtricleByCategories=(categorie)=>{
    return new Promise((resolve,reject)=>{
        pool.getConnection((err,connection)=>{
            if(err) reject(err)
            connection.query(sql.queryCategories,categorie,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
    });
}

exports.getAtricleByTags=(tag)=>{
    return new Promise((resolve,reject)=>{
        let val=`%${tag}%`
        pool.getConnection((err,connection)=>{
            if(err) reject(err)
            connection.query(sql.queryTags,val,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
    });
}

exports.getLikeAtricle=(title)=>{
    return new Promise((resolve, reject) => {
        let val=`%${title}%`
        pool.getConnection((err,connection)=>{
            if(err) reject(err)
            connection.query(sql.queryLike,val,(err,result)=>{
                console.log(result);
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
    })
}
