const mysql=require('mysql')
const config=require('../mysql/config');
const pool=mysql.createPool(config);


const sql={
    queryAll:"SELECT id,tagname FROM tags",
    queryTagsCount:"SELECT COUNT(tagname) FROM tags WHERE tagname=?",
    insert:"INSERT INTO tags(tagname) VALUES(?)"
}

exports.getTags=()=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) reject(err)
            connection.query(sql.queryAll,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
    })
}

exports.insertTags=(tagname)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) reject(err)
            connection.query(sql.insert,tagname,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
    })
}

exports.getTagsCount=(tagname)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err) reject(err)
            connection.query(sql.queryTagsCount,tagname,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end()
        })
    })
}