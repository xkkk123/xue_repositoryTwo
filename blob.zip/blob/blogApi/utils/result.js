class Result{
    constructor(){}

    success(code,msg,data){
        return {
            code,
            msg,
            data
        }
    }

    fail(code,msg,data){
        return {
            code,
            msg,
            data
        }
    }

}
module.exports=new Result()