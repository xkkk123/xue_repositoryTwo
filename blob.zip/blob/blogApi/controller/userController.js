const express=require('express');
const userService=require('../service/userService');
const result=require('../utils/result')

const router=express.Router();

router.post('/login',function(req,res,next){
    userService.login(req.body).then(data=>{
        res.send(result.success(200,"登录成功！",data))
    })
    .catch(err=>{
        res.send(result.fail(400,"账号或密码错误！",err))
    })
})
router.post("/register",function(req,res){
    userService.insertUser(req.body).then((data)=>{
        console.log(data)
        res.send(result.success(200,"注册成功！",null))
    }).catch(err=>{
        res.send(result.fail(400,"用户名已被占用",err))
    })
})

router.get('/getToken',function(req,res){
    res.send({
        code:200,
        msg:'成功',
        data:req.auth
    })
})
module.exports=router;