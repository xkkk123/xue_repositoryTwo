const express=require('express');
const categoriesService=require('../service/categoriesService');
const result=require('../utils/result')

const router=express.Router();

router.get("/getCategories",(req,res,next)=>{
    categoriesService.getCategories().then(data=>{
        res.send(result.success(200,"成功！",data))
    }).catch(err=>{
        res.send(result.success(400,"失败！",err))
    })
})
module.exports=router;