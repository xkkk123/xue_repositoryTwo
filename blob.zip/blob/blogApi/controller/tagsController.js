const express=require('express');
const tagsService=require('../service/tagsService');
const result=require('../utils/result')

const router=express.Router();

router.get("/getTags",(req,res,next)=>{
    tagsService.getTags().then(data=>{
        res.send(result.success(200,"成功！",data))
        console.log(data);
    }).catch(err=>{
        res.send(result.success(400,"失败！",err))
    })
})

module.exports=router;