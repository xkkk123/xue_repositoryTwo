const express=require('express');
const articleService=require('../service/articleService')
const result=require('../utils/result');
const { json } = require('body-parser');
const router=express.Router();

router.post("/setArticle",(req,res,next)=>{
    articleService.setArticle(req.body).then(data=>{
        res.send(result.success(200,"成功",data))
    }).catch(err=>{
        res.send(result.fail(400,"失败",err))
    })
})

router.get("/getArticleAll",(req,res,next)=>{
    articleService.getArticleAll().then(data=>{
        res.send(result.success(200,"成功",data))
    }).catch(err=>{
        res.send(result.fail(400,"失败",err))
    })
})

router.get("/getArticle",(req,res,next)=>{
    articleService.getArticle(req.query.page,req.query.limit).then(data=>{
        res.send(result.success(200,"成功",data))
    }).catch(err=>{
       res.send(result.fail(400,"失败",err))
    })
})

router.get("/getArticleById",(req,res,next)=>{
    console.log(req.query.id);
    articleService.getArticleById(req.query.id).then((data)=>{
        res.send(result.success(200,"成功",data))
    }).catch((err)=>{
        res.send(result.fail(400,"失败",err))
    })
})

router.get("/getCategoriesArticle",(req,res,next)=>{
    articleService.getCategoriesArticle(req.query.categorie).then(data=>{
        console.log(data);
        res.send(result.success(200,"成功",data))
    }).catch((err)=>{
        res.send(result.fail(400,"失败",err))
    })
})

router.get("/getTagsArticle",(req,res,next)=>{
    articleService.getTagsArticle(req.query.tag).then(data=>{
        console.log(data);
        res.send(result.success(200,"成功",data))
    }).catch((err)=>{
        res.send(result.fail(400,"失败",err))
    })
})

router.get("/getLikeArticle",(req,res,next)=>{
    console.log(req.query.title);
    articleService.getLikeArticle(req.query.title).then(data=>{
        res.send(result.success(200,"成功",data))
    }).catch(err=>{
        res.send(result.fail(400,"失败",err))
    })
})

module.exports=router;