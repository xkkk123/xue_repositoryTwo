const config={
    host:'localhost',
    user:'root',
    password:'root',
    database:'blog'
}

module.exports=config;